<?php
session_start();
require_once '../config/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idNumber = trim($_POST['id_number']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE id_number = ?");
    $stmt->execute([$idNumber]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['role'] = $user['role'];

        if ($user['role'] === 'teacher') {
            header("Location: ../teacher/dashboard.php");
        } else {
            header("Location: ../student/dashboard.php");
        }
        exit();
    } else {
        $error = "Invalid ID Number or Password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Classroom Monitoring System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body class="d-flex align-items-center justify-content-center vh-100">
<div class="card p-4 shadow-sm" style="width: 100%; max-width: 400px;">
    <h3 class="text-center text-success mb-3">Welcome Back</h3>
    <p class="text-center text-muted small mb-4">Classroom Monitoring System</p>
    
    <?php if ($error): ?><div class="alert alert-danger py-2 small"><?= $error ?></div><?php endif; ?>
    
    <form method="POST">
        <div class="mb-3">
            <label class="form-label">ID Number</label>
            <input type="text" name="id_number" class="form-control" required placeholder="Enter Student or Teacher ID">
        </div>
        <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-pastel-green w-100">Sign In</button>
    </form>
    <p class="text-center mt-3 text-muted small">New student? <a href="register.php">Create an account</a></p>
</div>
</body>
</html>