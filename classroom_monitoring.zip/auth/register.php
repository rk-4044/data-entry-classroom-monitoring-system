<?php
session_start();
require_once '../config/db.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role        = $_POST['role'] ?? 'student';
    $fullName    = trim($_POST['full_name']);
    $idNumber    = trim($_POST['id_number']);
    $email       = trim($_POST['email']);
    $password    = $_POST['password'];

    // Student-specific fields
    $course      = trim($_POST['course'] ?? '');
    $yearSection = trim($_POST['year_section'] ?? '');
    $address     = trim($_POST['address'] ?? '');
    $status      = $_POST['status'] ?? 'Regular';

    if (!empty($fullName) && !empty($idNumber) && !empty($email) && !empty($password)) {
        try {
            $pdo->beginTransaction();

            // Insert into users table with selected role
            $stmt = $pdo->prepare("INSERT INTO users (id_number, full_name, email, password, role) VALUES (?, ?, ?, ?, ?)");
            $hashedPass = password_hash($password, PASSWORD_BCRYPT);
            $stmt->execute([$idNumber, $fullName, $email, $hashedPass, $role]);
            $userId = $pdo->lastInsertId();

            // If registering as a student, create the student profile
            if ($role === 'student') {
                $stmtProfile = $pdo->prepare("INSERT INTO student_profiles (user_id, course, year_section, address, status) VALUES (?, ?, ?, ?, ?)");
                $stmtProfile->execute([$userId, $course, $yearSection, $address, $status]);
            }

            $pdo->commit();
            $success = "Registration successful as a " . ucfirst($role) . "! You can now log in.";
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = "Registration failed. ID Number or Email may already exist.";
        }
    } else {
        $error = "Please fill in all required fields.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Account Registration - Classroom Monitoring</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body class="d-flex align-items-center justify-content-center py-5">
<div class="container" style="max-width: 600px;">
    <div class="card p-4 shadow-sm">
        <h3 class="text-center mb-2 text-success">Create an Account</h3>
        <p class="text-center text-muted small mb-4">Data Entry Classroom Monitoring System</p>
        
        <?php if ($error): ?><div class="alert alert-danger py-2 small"><?= $error ?></div><?php endif; ?>
        <?php if ($success): ?><div class="alert alert-success py-2 small"><?= $success ?></div><?php endif; ?>
        
        <form method="POST" id="regForm">
            <div class="mb-3">
                <label class="form-label fw-bold">Registering as:</label>
                <div class="d-flex gap-4">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="role" id="roleStudent" value="student" checked onclick="toggleRoleFields()">
                        <label class="form-check-label" for="roleStudent">Student</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="role" id="roleTeacher" value="teacher" onclick="toggleRoleFields()">
                        <label class="form-check-label" for="roleTeacher">Teacher / Admin</label>
                    </div>
                </div>
            </div>

            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Full Name</label>
                    <input type="text" name="full_name" class="form-control" placeholder="e.g. Maria Santos" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label" id="idLabel">Student ID Number</label>
                    <input type="text" name="id_number" class="form-control" placeholder="e.g. 2024-00123" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" placeholder="user@school.edu" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>

                <!-- Dynamic Student Fields -->
                <div id="studentFields" class="row g-3 m-0 p-0">
                    <div class="col-md-6 ps-0">
                        <label class="form-label">Course</label>
                        <input type="text" name="course" id="courseInput" class="form-control" placeholder="e.g., BSIT" required>
                    </div>
                    <div class="col-md-6 pe-0">
                        <label class="form-label">Year & Section</label>
                        <input type="text" name="year_section" id="yearInput" class="form-control" placeholder="e.g., 3-A" required>
                    </div>
                    <div class="col-12 p-0">
                        <label class="form-label">Address</label>
                        <textarea name="address" id="addressInput" class="form-control" rows="2" required></textarea>
                    </div>
                    <div class="col-12 p-0 mt-2">
                        <label class="form-label">Academic Status</label>
                        <select name="status" class="form-select">
                            <option value="Regular">Regular</option>
                            <option value="Irregular">Irregular</option>
                        </select>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-pastel-green w-100 mt-4">Register Account</button>
        </form>
        <p class="text-center mt-3 text-muted small mb-0">Already registered? <a href="login.php">Login here</a></p>
    </div>
</div>

<script>
function toggleRoleFields() {
    const isTeacher = document.getElementById('roleTeacher').checked;
    const studentFields = document.getElementById('studentFields');
    const idLabel = document.getElementById('idLabel');
    const courseInput = document.getElementById('courseInput');
    const yearInput = document.getElementById('yearInput');
    const addressInput = document.getElementById('addressInput');

    if (isTeacher) {
        studentFields.style.display = 'none';
        idLabel.innerText = 'Teacher / Employee ID';
        courseInput.removeAttribute('required');
        yearInput.removeAttribute('required');
        addressInput.removeAttribute('required');
    } else {
        studentFields.style.display = 'flex';
        idLabel.innerText = 'Student ID Number';
        courseInput.setAttribute('required', '');
        yearInput.setAttribute('required', '');
        addressInput.setAttribute('required', '');
    }
}
</script>
</body>
</html>