<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../auth/login.php");
    exit();
}

$studentId = $_SESSION['user_id'];
$message = '';

// Join Classroom via Code
if (isset($_POST['join_class'])) {
    $code = trim($_POST['class_code']);

    $stmtClass = $pdo->prepare("SELECT classroom_id FROM classrooms WHERE class_code = ?");
    $stmtClass->execute([$code]);
    $class = $stmtClass->fetch();

    if ($class) {
        try {
            $stmtEnroll = $pdo->prepare("INSERT INTO enrollments (classroom_id, student_id) VALUES (?, ?)");
            $stmtEnroll->execute([$class['classroom_id'], $studentId]);
            $message = "Enrolled successfully in classroom!";
        } catch (PDOException $e) {
            $message = "You are already enrolled in this class.";
        }
    } else {
        $message = "Invalid class code.";
    }
}

// Fetch Enrolled Classrooms
$stmtClasses = $pdo->prepare("
    SELECT c.*, u.full_name as teacher_name 
    FROM classrooms c 
    JOIN enrollments e ON c.classroom_id = e.classroom_id 
    JOIN users u ON c.teacher_id = u.user_id 
    WHERE e.student_id = ?
");
$stmtClasses->execute([$studentId]);
$myClasses = $stmtClasses->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light px-4">
    <span class="navbar-brand fw-bold text-success">Student Portal</span>
    <div class="ms-auto d-flex align-items-center gap-3">
        <a href="profile.php" class="btn btn-sm btn-soft-blue">My Profile</a>
        <a href="../auth/logout.php" class="btn btn-outline-danger btn-sm">Logout</a>
    </div>
</nav>

<div class="container py-4" style="max-width: 800px;">
    <?php if ($message): ?><div class="alert alert-info py-2"><?= $message ?></div><?php endif; ?>

    <!-- Join Class Bar -->
    <div class="card p-3 mb-4">
        <form method="POST" class="row g-2 align-items-center">
            <div class="col-auto">
                <label class="fw-bold text-success">Enroll in Classroom:</label>
            </div>
            <div class="col-auto">
                <input type="text" name="class_code" class="form-control form-control-sm" placeholder="Enter Class Code" required>
            </div>
            <div class="col-auto">
                <button type="submit" name="join_class" class="btn btn-pastel-green btn-sm">Join Class</button>
            </div>
        </form>
    </div>

    <!-- Enrolled Classrooms List -->
    <h5 class="text-success mb-3">My Enrolled Classrooms</h5>
    <?php if (empty($myClasses)): ?>
        <div class="card p-3 text-muted">You are not enrolled in any classrooms yet. Enter a class code above to register.</div>
    <?php else: ?>
        <div class="row g-3">
            <?php foreach ($myClasses as $c): ?>
                <div class="col-md-6">
                    <div class="card p-3 shadow-sm border">
                        <div class="d-flex justify-content-between align-items-center">
                            <h6 class="m-0 text-success fw-bold"><?= htmlspecialchars($c['subject_code']) ?></h6>
                            <span class="badge badge-regular"><?= htmlspecialchars($c['schedule']) ?></span>
                        </div>
                        <p class="m-0 text-dark small mt-1"><?= htmlspecialchars($c['subject_title']) ?></p>
                        <small class="text-muted d-block mb-3">Instructor: <?= htmlspecialchars($c['teacher_name']) ?></small>
                        <a href="view_classroom.php?id=<?= $c['classroom_id'] ?>" class="btn btn-soft-blue btn-sm w-100">Enter Classroom</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
</body>
</html>