<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../auth/login.php");
    exit();
}

$studentId = $_SESSION['user_id'];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $course      = trim($_POST['course']);
    $yearSection = trim($_POST['year_section']);
    $address     = trim($_POST['address']);

    $stmt = $pdo->prepare("UPDATE student_profiles SET course = ?, year_section = ?, address = ? WHERE user_id = ?");
    $stmt->execute([$course, $yearSection, $address, $studentId]);
    $message = "Profile updated successfully!";
}

$stmt = $pdo->prepare("
    SELECT u.id_number, u.full_name, u.email, sp.course, sp.year_section, sp.address, sp.status 
    FROM users u 
    JOIN student_profiles sp ON u.user_id = sp.user_id 
    WHERE u.user_id = ?
");
$stmt->execute([$studentId]);
$profile = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="container py-5" style="max-width: 600px;">
    <div class="card p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h4 class="text-success m-0">My Personal Profile</h4>
            <a href="dashboard.php" class="btn btn-outline-secondary btn-sm">Back to Dashboard</a>
        </div>

        <?php if ($message): ?><div class="alert alert-success py-2 small"><?= $message ?></div><?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label class="form-label small text-muted">Full Name (Read-Only)</label>
                <input type="text" class="form-control" value="<?= htmlspecialchars($profile['full_name']) ?>" disabled>
            </div>
            <div class="mb-3">
                <label class="form-label small text-muted">Student ID (Read-Only)</label>
                <input type="text" class="form-control" value="<?= htmlspecialchars($profile['id_number']) ?>" disabled>
            </div>
            <div class="mb-3">
                <label class="form-label small text-muted">Academic Status (Read-Only)</label>
                <input type="text" class="form-control" value="<?= htmlspecialchars($profile['status']) ?>" disabled>
            </div>
            <div class="mb-3">
                <label class="form-label">Course</label>
                <input type="text" name="course" class="form-control" value="<?= htmlspecialchars($profile['course']) ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Year & Section</label>
                <input type="text" name="year_section" class="form-control" value="<?= htmlspecialchars($profile['year_section']) ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Address</label>
                <textarea name="address" class="form-control" rows="3" required><?= htmlspecialchars($profile['address']) ?></textarea>
            </div>
            <button type="submit" class="btn btn-pastel-green w-100">Save Profile Updates</button>
        </form>
    </div>
</div>
</body>
</html>