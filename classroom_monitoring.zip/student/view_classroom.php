<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../auth/login.php");
    exit();
}

$classId   = $_GET['id'] ?? null;
$studentId = $_SESSION['user_id'];
$message   = '';

// Verify Student Enrollment
$stmtEnroll = $pdo->prepare("
    SELECT c.*, u.full_name as teacher_name 
    FROM classrooms c 
    JOIN enrollments e ON c.classroom_id = e.classroom_id 
    JOIN users u ON c.teacher_id = u.user_id 
    WHERE c.classroom_id = ? AND e.student_id = ?
");
$stmtEnroll->execute([$classId, $studentId]);
$classroom = $stmtEnroll->fetch();

if (!$classroom) {
    header("Location: dashboard.php");
    exit();
}

// Handle Task Submission Entry
if (isset($_POST['submit_task'])) {
    $taskId         = $_POST['task_id'];
    $submissionText = trim($_POST['submission_text']);

    if (!empty($submissionText)) {
        // Check if student already submitted
        $stmtCheck = $pdo->prepare("SELECT submission_id FROM submissions WHERE task_id = ? AND student_id = ?");
        $stmtCheck->execute([$taskId, $studentId]);
        $existing = $stmtCheck->fetch();

        if ($existing) {
            // Update existing submission
            $stmtUpdate = $pdo->prepare("UPDATE submissions SET submission_text = ?, submitted_at = CURRENT_TIMESTAMP WHERE submission_id = ?");
            $stmtUpdate->execute([$submissionText, $existing['submission_id']]);
            $message = "Submission updated successfully!";
        } else {
            // Insert new submission
            $stmtInsert = $pdo->prepare("INSERT INTO submissions (task_id, student_id, submission_text) VALUES (?, ?, ?)");
            $stmtInsert->execute([$taskId, $studentId, $submissionText]);
            $message = "Task submitted successfully!";
        }
    }
}

// Fetch Classroom Tasks
$stmtTasks = $pdo->prepare("SELECT * FROM tasks WHERE classroom_id = ? ORDER BY due_date ASC");
$stmtTasks->execute([$classId]);
$tasks = $stmtTasks->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($classroom['subject_code']) ?> - Student View</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light px-4">
    <a href="dashboard.php" class="btn btn-outline-secondary btn-sm me-3">&larr; Back to Dashboard</a>
    <span class="navbar-brand fw-bold text-success"><?= htmlspecialchars($classroom['subject_code']) ?>: <?= htmlspecialchars($classroom['subject_title']) ?></span>
    <span class="ms-auto small text-muted">Instructor: <strong><?= htmlspecialchars($classroom['teacher_name']) ?></strong></span>
</nav>

<div class="container py-4" style="max-width: 800px;">
    <?php if ($message): ?><div class="alert alert-success py-2"><?= $message ?></div><?php endif; ?>

    <h5 class="text-success mb-3">Classroom Tasks</h5>

    <?php if (empty($tasks)): ?>
        <div class="card p-3 text-muted">No tasks assigned in this classroom.</div>
    <?php else: ?>
        <?php foreach ($tasks as $t): ?>
            <?php
            // Fetch ONLY this student's submission for this specific task
            $stmtMySub = $pdo->prepare("SELECT * FROM submissions WHERE task_id = ? AND student_id = ?");
            $stmtMySub->execute([$t['task_id'], $studentId]);
            $mySubmission = $stmtMySub->fetch();
            ?>
            <div class="card p-4 mb-3 border">
                <div class="d-flex justify-content-between align-items-start">
                    <h5 class="text-dark fw-bold m-0"><?= htmlspecialchars($t['title']) ?></h5>
                    <span class="badge bg-danger">Due: <?= date('M d, g:i A', strtotime($t['due_date'])) ?></span>
                </div>
                <p class="text-secondary small mt-2 mb-3"><?= nl2br(htmlspecialchars($t['description'])) ?></p>

                <!-- Student Personal Submission Section -->
                <div class="p-3 bg-light rounded border">
                    <h6 class="text-success fw-bold small mb-2">My Submission Record</h6>
                    
                    <?php if ($mySubmission): ?>
                        <div class="alert alert-success py-2 small mb-2">
                            <strong>Submitted on:</strong> <?= date('M d, Y g:i A', strtotime($mySubmission['submitted_at'])) ?>
                        </div>
                        <p class="small text-dark bg-white p-2 border rounded"><?= nl2br(htmlspecialchars($mySubmission['submission_text'])) ?></p>
                    <?php else: ?>
                        <p class="small text-muted mb-2">You haven't submitted your work for this task yet.</p>
                    <?php endif; ?>

                    <!-- Form to submit/update task entry -->
                    <form method="POST" class="mt-2">
                        <input type="hidden" name="task_id" value="<?= $t['task_id'] ?>">
                        <textarea name="submission_text" class="form-control form-control-sm mb-2" rows="2" placeholder="Type your task entry, response, or upload link here..." required><?= $mySubmission ? htmlspecialchars($mySubmission['submission_text']) : '' ?></textarea>
                        <button type="submit" name="submit_task" class="btn btn-pastel-green btn-sm">
                            <?= $mySubmission ? 'Update My Submission' : 'Submit Task Entry' ?>
                        </button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
</body>
</html>