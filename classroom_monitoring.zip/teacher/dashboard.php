<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header("Location: ../auth/login.php");
    exit();
}

$teacherId = $_SESSION['user_id'];
$message = '';

// Handle Classroom Creation
if (isset($_POST['create_class'])) {
    $code  = trim($_POST['subject_code']);
    $title = trim($_POST['subject_title']);
    $sched = trim($_POST['schedule']);
    $classCode = strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 6));

    $stmt = $pdo->prepare("INSERT INTO classrooms (teacher_id, subject_code, subject_title, class_code, schedule) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$teacherId, $code, $title, $classCode, $sched]);
    $message = "Classroom created successfully! Class Code: <strong>$classCode</strong>";
}

// Handle Student Profile Update by Teacher/Admin
if (isset($_POST['update_student'])) {
    $studentUserId = $_POST['student_user_id'];
    $course        = trim($_POST['course']);
    $yearSection   = trim($_POST['year_section']);
    $status        = $_POST['status'];

    $stmt = $pdo->prepare("UPDATE student_profiles SET course = ?, year_section = ?, status = ? WHERE user_id = ?");
    $stmt->execute([$course, $yearSection, $status, $studentUserId]);
    $message = "Student information updated successfully.";
}

// Fetch Teacher's Classrooms
$stmtClasses = $pdo->prepare("SELECT * FROM classrooms WHERE teacher_id = ? ORDER BY created_at DESC");
$stmtClasses->execute([$teacherId]);
$classrooms = $stmtClasses->fetchAll();

// Search & View Students
$search = $_GET['search'] ?? '';
$sql = "SELECT u.user_id, u.id_number, u.full_name, u.email, sp.course, sp.year_section, sp.address, sp.status 
        FROM users u 
        JOIN student_profiles sp ON u.user_id = sp.user_id 
        WHERE u.role = 'student'";
if ($search) {
    $sql .= " AND (u.full_name LIKE :s OR u.id_number LIKE :s OR sp.course LIKE :s)";
}
$stmtStudents = $pdo->prepare($sql);
if ($search) {
    $stmtStudents->execute(['s' => "%$search%"]);
} else {
    $stmtStudents->execute();
}
$students = $stmtStudents->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Teacher Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light px-4">
    <span class="navbar-brand fw-bold text-success">Teacher Panel</span>
    <div class="ms-auto d-flex align-items-center gap-3">
        <span>Welcome, <strong><?= htmlspecialchars($_SESSION['full_name']) ?></strong></span>
        <a href="../auth/logout.php" class="btn btn-outline-danger btn-sm">Logout</a>
    </div>
</nav>

<div class="container py-4">
    <?php if ($message): ?><div class="alert alert-info py-2"><?= $message ?></div><?php endif; ?>

    <div class="row g-4 mb-4">
        <!-- Create Classroom Form -->
        <div class="col-md-4">
            <div class="card p-3">
                <h5 class="text-success mb-3">Create New Classroom</h5>
                <form method="POST">
                    <div class="mb-2">
                        <label class="form-label small">Subject Code</label>
                        <input type="text" name="subject_code" class="form-control" placeholder="e.g., IT 101" required>
                    </div>
                    <div class="mb-2">
                        <label class="form-label small">Subject Title</label>
                        <input type="text" name="subject_title" class="form-control" placeholder="e.g., Data Structures" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small">Schedule</label>
                        <input type="text" name="schedule" class="form-control" placeholder="e.g., Mon/Wed 10:00 AM" required>
                    </div>
                    <button type="submit" name="create_class" class="btn btn-soft-blue w-100">Create Classroom</button>
                </form>
            </div>
        </div>

        <!-- Classrooms List -->
        <div class="col-md-8">
            <div class="card p-3">
                <h5 class="text-success mb-3">My Classrooms</h5>
                <?php if (empty($classrooms)): ?>
                    <p class="text-muted">No classrooms created yet. Create one using the form.</p>
                <?php else: ?>
                    <div class="row g-3">
                        <?php foreach ($classrooms as $c): ?>
                            <div class="col-md-6">
                                <div class="card p-3 border shadow-sm">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <h6 class="text-success fw-bold m-0"><?= htmlspecialchars($c['subject_code']) ?></h6>
                                        <span class="badge badge-regular"><?= htmlspecialchars($c['class_code']) ?></span>
                                    </div>
                                    <p class="small text-dark fw-semibold mt-1 mb-1"><?= htmlspecialchars($c['subject_title']) ?></p>
                                    <small class="text-muted mb-3 d-block"><?= htmlspecialchars($c['schedule']) ?></small>
                                    <a href="view_classroom.php?id=<?= $c['classroom_id'] ?>" class="btn btn-pastel-green btn-sm w-100">Enter Classroom</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Student Directory Section -->
    <div class="card p-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="text-success m-0">Student Directory & Records</h5>
            <form method="GET" class="d-flex gap-2" style="max-width: 300px;">
                <input type="text" name="search" class="form-control form-control-sm" placeholder="Search ID or Name..." value="<?= htmlspecialchars($search) ?>">
                <button type="submit" class="btn btn-soft-blue btn-sm">Search</button>
            </form>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th>ID Number</th>
                        <th>Name</th>
                        <th>Course & Year</th>
                        <th>Status</th>
                        <th>Address</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $st): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($st['id_number']) ?></strong></td>
                        <td><?= htmlspecialchars($st['full_name']) ?></td>
                        <td><?= htmlspecialchars($st['course'] . ' - ' . $st['year_section']) ?></td>
                        <td>
                            <span class="badge <?= $st['status'] === 'Regular' ? 'badge-regular' : 'badge-irregular' ?>">
                                <?= htmlspecialchars($st['status']) ?>
                            </span>
                        </td>
                        <td class="small text-muted"><?= htmlspecialchars($st['address']) ?></td>
                        <td>
                            <button class="btn btn-sm btn-soft-blue" data-bs-toggle="modal" data-bs-target="#editStudent<?= $st['user_id'] ?>">Edit</button>

                            <!-- Edit Modal -->
                            <div class="modal fade" id="editStudent<?= $st['user_id'] ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form method="POST">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Edit <?= htmlspecialchars($st['full_name']) ?></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <input type="hidden" name="student_user_id" value="<?= $st['user_id'] ?>">
                                                <div class="mb-2">
                                                    <label class="form-label small">Course</label>
                                                    <input type="text" name="course" class="form-control" value="<?= htmlspecialchars($st['course']) ?>" required>
                                                </div>
                                                <div class="mb-2">
                                                    <label class="form-label small">Year & Section</label>
                                                    <input type="text" name="year_section" class="form-control" value="<?= htmlspecialchars($st['year_section']) ?>" required>
                                                </div>
                                                <div class="mb-2">
                                                    <label class="form-label small">Status</label>
                                                    <select name="status" class="form-select">
                                                        <option value="Regular" <?= $st['status'] === 'Regular' ? 'selected' : '' ?>>Regular</option>
                                                        <option value="Irregular" <?= $st['status'] === 'Irregular' ? 'selected' : '' ?>>Irregular</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="submit" name="update_student" class="btn btn-pastel-green btn-sm">Save Changes</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>