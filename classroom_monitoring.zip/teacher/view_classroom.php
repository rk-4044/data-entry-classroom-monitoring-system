<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header("Location: ../auth/login.php");
    exit();
}

$classId = $_GET['id'] ?? null;
$teacherId = $_SESSION['user_id'];
$message = '';

// Fetch Classroom Details
$stmtClass = $pdo->prepare("SELECT * FROM classrooms WHERE classroom_id = ? AND teacher_id = ?");
$stmtClass->execute([$classId, $teacherId]);
$classroom = $stmtClass->fetch();

if (!$classroom) {
    header("Location: dashboard.php");
    exit();
}

// Handle Task Assignment
if (isset($_POST['create_task'])) {
    $title   = trim($_POST['task_title']);
    $desc    = trim($_POST['task_desc']);
    $dueDate = $_POST['due_date'];

    $stmt = $pdo->prepare("INSERT INTO tasks (classroom_id, title, description, due_date) VALUES (?, ?, ?, ?)");
    $stmt->execute([$classId, $title, $desc, $dueDate]);
    $message = "Task assigned successfully!";
}

// Fetch Classroom Tasks
$stmtTasks = $pdo->prepare("SELECT * FROM tasks WHERE classroom_id = ? ORDER BY created_at DESC");
$stmtTasks->execute([$classId]);
$tasks = $stmtTasks->fetchAll();

// Fetch Enrolled Students Count
$stmtStudents = $pdo->prepare("
    SELECT u.full_name, u.id_number, sp.course, sp.year_section 
    FROM enrollments e 
    JOIN users u ON e.student_id = u.user_id 
    JOIN student_profiles sp ON u.user_id = sp.user_id 
    WHERE e.classroom_id = ?
");
$stmtStudents->execute([$classId]);
$enrolledStudents = $stmtStudents->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($classroom['subject_code']) ?> - Teacher View</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light px-4">
    <a href="dashboard.php" class="btn btn-outline-secondary btn-sm me-3">&larr; Back to Dashboard</a>
    <span class="navbar-brand fw-bold text-success"><?= htmlspecialchars($classroom['subject_code']) ?>: <?= htmlspecialchars($classroom['subject_title']) ?></span>
    <span class="ms-auto badge badge-regular p-2">Class Code: <?= htmlspecialchars($classroom['class_code']) ?></span>
</nav>

<div class="container py-4">
    <?php if ($message): ?><div class="alert alert-success py-2"><?= $message ?></div><?php endif; ?>

    <div class="row g-4">
        <!-- Assign New Task Form -->
        <div class="col-md-4">
            <div class="card p-3 mb-4">
                <h5 class="text-success mb-3">Post New Task</h5>
                <form method="POST">
                    <div class="mb-2">
                        <label class="form-label small">Task Title</label>
                        <input type="text" name="task_title" class="form-control" required>
                    </div>
                    <div class="mb-2">
                        <label class="form-label small">Description / Instructions</label>
                        <textarea name="task_desc" class="form-control" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small">Due Date</label>
                        <input type="datetime-local" name="due_date" class="form-control" required>
                    </div>
                    <button type="submit" name="create_task" class="btn btn-pastel-green w-100">Post Task</button>
                </form>
            </div>

            <!-- Enrolled Students Summary -->
            <div class="card p-3">
                <h6 class="text-success fw-bold mb-2">Enrolled Students (<?= count($enrolledStudents) ?>)</h6>
                <ul class="list-group list-group-flush small">
                    <?php foreach ($enrolledStudents as $s): ?>
                        <li class="list-group-item bg-transparent px-0 py-1">
                            <strong><?= htmlspecialchars($s['full_name']) ?></strong> (<?= htmlspecialchars($s['id_number']) ?>)
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>

        <!-- Class Tasks & Student Submissions -->
        <div class="col-md-8">
            <h5 class="text-success mb-3">Assigned Tasks & Student Submissions</h5>
            <?php if (empty($tasks)): ?>
                <div class="card p-3 text-muted">No tasks posted in this classroom yet.</div>
            <?php else: ?>
                <?php foreach ($tasks as $t): ?>
                    <?php
                    // Fetch Submissions for this task
                    $stmtSub = $pdo->prepare("
                        SELECT s.*, u.full_name, u.id_number 
                        FROM submissions s 
                        JOIN users u ON s.student_id = u.user_id 
                        WHERE s.task_id = ? 
                        ORDER BY s.submitted_at DESC
                    ");
                    $stmtSub->execute([$t['task_id']]);
                    $submissions = $stmtSub->fetchAll();
                    ?>
                    <div class="card p-3 mb-3 border">
                        <div class="d-flex justify-content-between align-items-start">
                            <h5 class="text-dark m-0 fw-bold"><?= htmlspecialchars($t['title']) ?></h5>
                            <span class="badge bg-danger">Due: <?= date('M d, g:i A', strtotime($t['due_date'])) ?></span>
                        </div>
                        <p class="text-muted small mt-2 mb-3"><?= nl2br(htmlspecialchars($t['description'])) ?></p>

                        <!-- Student Submissions Breakdown -->
                        <div class="p-3 bg-light rounded">
                            <h6 class="text-success small fw-bold mb-2">Student Submissions (<?= count($submissions) ?>)</h6>
                            <?php if (empty($submissions)): ?>
                                <span class="small text-muted">No student submissions recorded yet.</span>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-sm table-bordered bg-white m-0 align-middle">
                                        <thead class="table-light">
                                            <tr>
                                                <th>Student ID</th>
                                                <th>Student Name</th>
                                                <th>Submission Content</th>
                                                <th>Submitted At</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($submissions as $sub): ?>
                                                <tr>
                                                    <td><strong><?= htmlspecialchars($sub['id_number']) ?></strong></td>
                                                    <td><?= htmlspecialchars($sub['full_name']) ?></td>
                                                    <td class="small"><?= nl2br(htmlspecialchars($sub['submission_text'])) ?></td>
                                                    <td class="small text-muted"><?= date('M d, g:i A', strtotime($sub['submitted_at'])) ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>